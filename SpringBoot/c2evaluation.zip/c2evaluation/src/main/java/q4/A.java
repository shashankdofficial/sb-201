package q4;

public class A {

	//Majourly we use 2 Dependencies:
		
		//spring web dependency
		//DevTools Dependency
	
	//spring web dependency, (This dependency will include an integrated Tomcat web server, in which our application
	//will be deployed)
	
	//After every change, we need to restart the server to deploy the application. If we want every change will automatically
	//re-deploy the application then we need to add the following DevTools dependency.
	
	
	
	
	
}
