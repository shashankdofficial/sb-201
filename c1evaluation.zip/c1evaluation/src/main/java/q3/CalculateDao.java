package q3;

import org.springframework.stereotype.Service;

@Service
public interface CalculateDao {
    public int[] getResult();
}
